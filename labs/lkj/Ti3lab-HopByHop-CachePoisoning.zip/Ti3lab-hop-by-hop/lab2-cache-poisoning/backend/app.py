from flask import Flask, request, jsonify, make_response
import time

app = Flask(__name__)

@app.route("/profile")
def profile():
    username = request.headers.get("X-User", "guest")
    response_data = {
        "lab": "Ti3lab - Lab 2: Cache Poisoning via Hop-by-Hop",
        "username": username,
        "message": f"Hello {username}, your profile data is cached.",
        "timestamp": int(time.time())
    }
    resp = make_response(jsonify(response_data))
    resp.headers["Cache-Control"] = "public, max-age=60"
    resp.headers["X-Cache-Key"] = "/profile"
    return resp

@app.route("/secret")
def secret():
    username = request.headers.get("X-User", "guest")
    if username == "admin":
        return jsonify({
            "status": "ok",
            "flag": "Ti3lab{c4ch3_p0is0n_v1a_h0p_h34d3rs}",
            "secret_data": "Admin session token: Ti3lab-AdminSecret-2024"
        })
    return jsonify({
        "status": "ok",
        "username": username,
        "secret_data": f"Nothing special for {username}"
    })

@app.route("/")
def index():
    return jsonify({
        "lab": "Ti3lab - Lab 2: Cache Poisoning",
        "endpoints": ["/profile", "/secret"]
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

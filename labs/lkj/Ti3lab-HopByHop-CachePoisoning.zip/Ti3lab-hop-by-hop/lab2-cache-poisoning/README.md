# Ti3lab - Lab 2: Cache Poisoning via Hop-by-Hop Headers

**Difficulty:** Medium  
**Category:** Proxy Abuse / Cache Poisoning

---

## Setup

```bash
docker compose up --build
```

Lab runs on: http://localhost:8082

---

## Objective

The cache server uses a shared cache key based only on the URI path.  
Poison the cache with your own injected header so that other users  
receive a response crafted by you.

Then use what you learn to access the `/secret` endpoint as admin.

---

## Endpoints

| Endpoint  | Description                             |
|-----------|-----------------------------------------|
| /         | Lab info                                |
| /profile  | Cached endpoint - vulnerable to poison  |
| /secret   | Returns different data based on X-User  |

---

## Background

Cache servers store responses and replay them for future requests.  
The cache key determines when a cached response is reused.  

If the cache key does not include a header that affects the response,  
an attacker can poison the cache: the attacker's header value gets cached  
and served to all users who request the same URI.

When combined with hop-by-hop header abuse, the attacker can inject  
custom headers that the proxy strips for itself but forwards to the backend,  
causing the backend response to differ from what the cache expects.

---

## Hints

<details>
<summary>Hint 1</summary>
Request /profile normally first. Check the X-Cache-Status response header.
What does HIT vs MISS tell you?
</details>

<details>
<summary>Hint 2</summary>
The cache key is only the URI path. Try sending X-User: admin in your request to /profile.
Does the response change? Does the cache store this version?
</details>

<details>
<summary>Hint 3</summary>
Make a request with X-User: admin to /profile while the cache is cold (after restart).
Then make a request without any X-User header.
What do you receive?
</details>

<details>
<summary>Hint 4</summary>
Now apply the same X-User: admin technique to /secret directly.
The cache is not involved there - what does the backend return for admin?
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

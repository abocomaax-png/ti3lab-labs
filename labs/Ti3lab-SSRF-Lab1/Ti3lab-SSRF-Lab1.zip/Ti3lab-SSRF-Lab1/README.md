# Ti3lab - SSRF Lab 1
## Basic SSRF: Internal Service Access

**Difficulty:** Easy
**Category:** Server-Side Request Forgery (SSRF)

---

## What is SSRF?

Server-Side Request Forgery (SSRF) is a vulnerability that allows an attacker to cause the server-side application to make HTTP requests to an arbitrary domain or IP address of the attacker's choosing.

The impact depends heavily on what internal services the vulnerable server can reach:

- Internal admin panels not exposed to the internet
- Cloud metadata endpoints (e.g. `169.254.169.254`)
- Internal databases, caches, or microservices
- Services bound only to localhost or private network ranges

### Attack Flow

```
Attacker                        Vulnerable Server              Internal Network
   |                                   |                              |
   |-- POST /api/webhook/test          |                              |
   |   { "url": "http://internal-api:8000/admin/flag" }              |
   |                                   |                              |
   |                                   |-- GET /admin/flag ---------->|
   |                                   |                              |
   |                                   |<-- 200 OK + sensitive data --|
   |                                   |                              |
   |<-- response with internal data ---|                              |
```

### Key Concepts

- **SSRF**: the server fetches a URL on your behalf — you control the destination
- **Internal network**: services inside Docker networks are not reachable from the internet, but are reachable from other containers on the same network
- **No validation**: when a server accepts a URL and fetches it without validating the host, any address the server can route to becomes reachable by the attacker

---

## Lab Scenario

You are testing **LinkPulse**, an uptime monitoring platform.

The platform allows users to configure webhook endpoints that receive notifications when a monitor changes state. Before saving a webhook, the platform offers a "Test" feature — it sends a request from its own servers to verify the webhook URL is reachable.

Explore the platform, find the feature that makes server-side requests, and think about what internal resources the server might be able to reach that you cannot.

---

## Tools

- **Burp Suite** — intercept and modify the webhook test request

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8085

---

## Hints

<details>
<summary>Hint 1</summary>
Find the feature on the platform that causes the server to make an outbound HTTP request. Try intercepting it with Burp Suite and look at exactly what gets sent to the server.
</details>

<details>
<summary>Hint 2</summary>
What parameter controls which URL the server fetches? What happens if you change that URL to point somewhere other than an external webhook receiver?
</details>

<details>
<summary>Hint 3</summary>
The application runs inside a Docker network alongside other services. Internal Docker service names are resolvable as hostnames within the same network. Think about what services might be running internally that aren't exposed to the internet.
</details>

<details>
<summary>Hint 4</summary>
Try targeting <code>http://internal-api:8000/</code> first to confirm connectivity. Then explore available paths on that internal service.
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

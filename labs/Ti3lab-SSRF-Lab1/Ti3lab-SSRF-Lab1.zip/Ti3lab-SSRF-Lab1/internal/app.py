from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route("/")
def index():
    return jsonify({"service": "Internal Admin API", "version": "1.0"})

@app.route("/admin/flag")
def flag():
    return jsonify({
        "service": "LinkPulse Internal Admin",
        "environment": "production",
        "flag": "Ti3lab{b4s1c_ssrf_int3rn4l_s3rv1c3_4cc3ss}"
    })

@app.route("/admin/users")
def users():
    return jsonify({
        "users": [
            {"id": 1, "email": "admin@linkpulse.io", "role": "admin"},
            {"id": 2, "email": "ops@linkpulse.io", "role": "operator"}
        ]
    })

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)

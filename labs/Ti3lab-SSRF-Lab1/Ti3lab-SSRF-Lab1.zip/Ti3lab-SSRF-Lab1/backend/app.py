from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

MONITORS = [
    {
        "id": 1,
        "name": "Production API",
        "url": "https://api.linkpulse.io/health",
        "status": "up",
        "uptime": "99.98%",
        "last_check": "2026-06-18T10:42:00Z"
    },
    {
        "id": 2,
        "name": "Payment Gateway",
        "url": "https://pay.linkpulse.io/ping",
        "status": "up",
        "uptime": "99.91%",
        "last_check": "2026-06-18T10:42:00Z"
    },
    {
        "id": 3,
        "name": "CDN Endpoint",
        "url": "https://cdn.linkpulse.io/healthz",
        "status": "degraded",
        "uptime": "98.20%",
        "last_check": "2026-06-18T10:41:55Z"
    }
]


@app.route("/api/monitors")
def monitors():
    return jsonify({"monitors": MONITORS})


@app.route("/api/webhook/test", methods=["POST"])
def webhook_test():
    """
    Vulnerable endpoint: accepts a user-supplied URL and fetches it
    server-side to verify the webhook is reachable. No URL validation
    is performed — the server will fetch any URL, including internal
    network addresses unreachable from the Internet.
    """
    data = request.get_json(silent=True) or {}
    url = data.get("url", "").strip()

    if not url:
        return jsonify({"status": "error", "message": "url is required"}), 400

    try:
        resp = requests.get(url, timeout=5, allow_redirects=True)
        return jsonify({
            "status": "success",
            "http_status": resp.status_code,
            "response_time_ms": int(resp.elapsed.total_seconds() * 1000),
            "body": resp.text[:2000]
        })
    except requests.exceptions.ConnectionError:
        return jsonify({"status": "error", "message": "Connection refused or host unreachable"}), 200
    except requests.exceptions.Timeout:
        return jsonify({"status": "error", "message": "Request timed out"}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 200


@app.route("/api/alerts")
def alerts():
    return jsonify({
        "alerts": [
            {"id": 1, "monitor": "CDN Endpoint", "message": "Latency above threshold", "time": "10:35 UTC"},
            {"id": 2, "monitor": "CDN Endpoint", "message": "Response time degraded", "time": "10:20 UTC"}
        ]
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

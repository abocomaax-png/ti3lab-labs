# Ti3lab - Lab 1: Hop-by-Hop Header Abuse
## X-Forwarded-For Bypass

**Difficulty:** Easy  
**Category:** Proxy Abuse / Hop-by-Hop Headers

---

## Setup

```bash
docker compose up --build
```

Lab runs on: http://localhost:8081

---

## Objective

The `/admin` endpoint is restricted to internal admin IPs only.  
Your goal is to gain access to the admin panel.

---

## Endpoints

| Endpoint  | Description                        |
|-----------|------------------------------------|
| /         | Lab info                           |
| /whoami   | Shows your resolved IP and headers |
| /admin    | Restricted to admin IPs only       |

---

## Background

Hop-by-hop headers are meant to be consumed by a single transport node and not forwarded.  
When a proxy misconfigures how it handles the `Connection` header, an attacker can abuse this  
to strip or inject headers that affect the backend's behavior.

Standard hop-by-hop headers include:
- Keep-Alive
- Transfer-Encoding
- TE
- Connection
- Trailer
- Upgrade
- Proxy-Authorization
- Proxy-Authenticate

Custom headers can also be declared as hop-by-hop via the `Connection` header itself.

---

## Hints

<details>
<summary>Hint 1</summary>
Start by hitting /whoami and observe how your IP reaches the backend.
What header is used to determine your identity?
</details>

<details>
<summary>Hint 2</summary>
The proxy forwards the X-Forwarded-For header as-is from the client.
Can you control what value ends up in that header?
</details>

<details>
<summary>Hint 3</summary>
Try sending:
Connection: close, X-Forwarded-For
X-Forwarded-For: 10.0.0.1

What happens when the proxy sees X-Forwarded-For listed inside Connection?
</details>

<details>
<summary>Hint 4 - Full Solution Direction</summary>
The proxy strips headers listed in the Connection header (hop-by-hop behavior).
But it also blindly passes X-Forwarded-For from the client before that.
Send a request where X-Forwarded-For contains a trusted admin IP.
The backend trusts this header to determine your identity.
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

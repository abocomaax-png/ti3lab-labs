from flask import Flask, request, jsonify

app = Flask(__name__)

ADMIN_IPS = ["10.0.0.1", "192.168.1.100", "172.16.0.1"]

@app.route("/admin")
def admin_panel():
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if client_ip in ADMIN_IPS:
        return jsonify({
            "status": "access_granted",
            "message": "Welcome to Ti3lab Admin Panel",
            "flag": "Ti3lab{h0p_by_h0p_byp4ss_succ3ss}",
            "your_ip": client_ip
        })
    else:
        return jsonify({
            "status": "access_denied",
            "message": "Access restricted to admin IPs only",
            "your_ip": client_ip
        }), 403

@app.route("/whoami")
def whoami():
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    headers_received = dict(request.headers)
    return jsonify({
        "resolved_ip": client_ip,
        "remote_addr": request.remote_addr,
        "headers": headers_received
    })

@app.route("/")
def index():
    return jsonify({
        "lab": "Ti3lab - Lab 1: Hop-by-Hop Header Abuse",
        "endpoints": ["/admin", "/whoami"]
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

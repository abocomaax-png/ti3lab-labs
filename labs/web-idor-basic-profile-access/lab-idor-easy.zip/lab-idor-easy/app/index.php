<?php
session_start();

// Fake users DB
$users = [
    1 => ['id' => 1, 'name' => 'Ahmed Hassan',  'email' => 'ahmed@ti3lab.com',  'role' => 'student', 'password' => 'ahmed123'],
    2 => ['id' => 2, 'name' => 'Sara Mohamed',  'email' => 'sara@ti3lab.com',   'role' => 'student', 'password' => 'sara456'],
    3 => ['id' => 3, 'name' => 'Omar Khalid',   'email' => 'omar@ti3lab.com',   'role' => 'student', 'password' => 'omar789'],
    4 => ['id' => 4, 'name' => 'Nour Admin',    'email' => 'nour@ti3lab.com',   'role' => 'admin',   'password' => 'nour_super_secret'],
    5 => ['id' => 5, 'name' => 'Youssef Ali',   'email' => 'youssef@ti3lab.com','role' => 'student', 'password' => 'youssef321'],
];

// Fake orders DB
$orders = [
    1  => ['id' => 1,  'user_id' => 1, 'item' => 'Web Hacking Course',    'price' => '$49',  'status' => 'paid'],
    2  => ['id' => 2,  'user_id' => 2, 'item' => 'Linux Mastery Course',   'price' => '$39',  'status' => 'paid'],
    3  => ['id' => 3,  'user_id' => 3, 'item' => 'Networking Fundamentals','price' => '$29',  'status' => 'paid'],
    4  => ['id' => 4,  'user_id' => 4, 'item' => 'VIP Admin Bundle',       'price' => '$199', 'status' => 'paid'],
    5  => ['id' => 5,  'user_id' => 5, 'item' => 'Pentesting Bootcamp',    'price' => '$59',  'status' => 'pending'],
    6  => ['id' => 6,  'user_id' => 1, 'item' => 'Bug Bounty Masterclass', 'price' => '$79',  'status' => 'paid'],
];

// Flag stored in user profile ID=4 (admin)
$flag = "ti3lab{1D0R_1s_4ll_4b0ut_th3_numb3r5}";
$users[4]['flag'] = $flag;

$page = $_GET['page'] ?? 'login';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $page === 'login') {
    $email = $_POST['email'] ?? '';
    $pass  = $_POST['password'] ?? '';
    foreach ($users as $u) {
        if ($u['email'] === $email && $u['password'] === $pass) {
            $_SESSION['user_id'] = $u['id'];
            header('Location: ?page=dashboard');
            exit;
        }
    }
    $_SESSION['login_error'] = 'Invalid credentials. Try again.';
    header('Location: ?page=login');
    exit;
}

// Handle logout
if ($page === 'logout') {
    session_destroy();
    header('Location: ?page=login');
    exit;
}

// Auth guard
$protected = ['dashboard', 'profile', 'order'];
if (in_array($page, $protected) && !isset($_SESSION['user_id'])) {
    header('Location: ?page=login');
    exit;
}

$currentUser = isset($_SESSION['user_id']) ? $users[$_SESSION['user_id']] ?? null : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ti3Lab Academy — Student Portal</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', sans-serif; background: #0a0a0f; color: #e0e0e0; min-height: 100vh; }

  /* Navbar */
  .navbar { background: #111118; border-bottom: 1px solid #1e1e2e; padding: 0 2rem; height: 60px; display: flex; align-items: center; justify-content: space-between; }
  .navbar .logo { font-size: 1.2rem; font-weight: 700; color: #7c3aed; letter-spacing: 1px; }
  .navbar .logo span { color: #a78bfa; }
  .nav-links a { color: #9ca3af; text-decoration: none; margin-left: 1.5rem; font-size: 0.9rem; transition: color .2s; }
  .nav-links a:hover { color: #fff; }
  .nav-links .logout { color: #f87171; }

  /* Layout */
  .container { max-width: 900px; margin: 2.5rem auto; padding: 0 1.5rem; }

  /* Card */
  .card { background: #111118; border: 1px solid #1e1e2e; border-radius: 12px; padding: 2rem; }
  .card h2 { font-size: 1.1rem; font-weight: 600; color: #c4b5fd; margin-bottom: 1.5rem; border-bottom: 1px solid #1e1e2e; padding-bottom: .75rem; }

  /* Forms */
  .form-group { margin-bottom: 1.2rem; }
  .form-group label { display: block; font-size: .82rem; color: #9ca3af; margin-bottom: .4rem; }
  .form-group input { width: 100%; background: #0a0a0f; border: 1px solid #2d2d3d; border-radius: 8px; padding: .65rem 1rem; color: #fff; font-size: .9rem; outline: none; transition: border .2s; }
  .form-group input:focus { border-color: #7c3aed; }
  .btn { display: inline-block; padding: .65rem 1.8rem; border-radius: 8px; font-size: .9rem; font-weight: 600; cursor: pointer; border: none; transition: all .2s; }
  .btn-primary { background: #7c3aed; color: #fff; }
  .btn-primary:hover { background: #6d28d9; }
  .btn-sm { padding: .35rem .9rem; font-size: .8rem; border-radius: 6px; }
  .btn-outline { background: transparent; border: 1px solid #3d3d5c; color: #9ca3af; }
  .btn-outline:hover { border-color: #7c3aed; color: #c4b5fd; }

  /* Alert */
  .alert { padding: .75rem 1rem; border-radius: 8px; font-size: .85rem; margin-bottom: 1rem; }
  .alert-error { background: #1a0a0a; border: 1px solid #7f1d1d; color: #fca5a5; }
  .alert-success { background: #0a1a0a; border: 1px solid #14532d; color: #86efac; }
  .alert-info { background: #0a0f1a; border: 1px solid #1e3a5f; color: #93c5fd; }

  /* Profile */
  .profile-header { display: flex; align-items: center; gap: 1.2rem; margin-bottom: 1.5rem; }
  .avatar { width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg,#7c3aed,#a78bfa); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; font-weight: 700; color: #fff; flex-shrink: 0; }
  .profile-info h3 { font-size: 1.05rem; font-weight: 600; }
  .profile-info .role-badge { display: inline-block; margin-top: .3rem; padding: .2rem .7rem; border-radius: 20px; font-size: .75rem; font-weight: 600; }
  .role-student { background: #1e1e4e; color: #818cf8; }
  .role-admin { background: #1a0a2e; color: #c084fc; }

  /* Table */
  table { width: 100%; border-collapse: collapse; font-size: .88rem; }
  th { text-align: left; padding: .6rem 1rem; color: #6b7280; font-size: .78rem; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; border-bottom: 1px solid #1e1e2e; }
  td { padding: .75rem 1rem; border-bottom: 1px solid #15151f; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: #13131c; }
  .badge { padding: .25rem .7rem; border-radius: 20px; font-size: .75rem; font-weight: 600; }
  .badge-paid { background: #052e16; color: #4ade80; }
  .badge-pending { background: #1c1917; color: #fb923c; }

  /* Flag box */
  .flag-box { background: #0d0a1a; border: 1px solid #4c1d95; border-radius: 10px; padding: 1.2rem 1.5rem; margin-top: 1rem; }
  .flag-box .flag-label { font-size: .75rem; color: #7c3aed; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-bottom: .4rem; }
  .flag-box code { font-family: monospace; font-size: 1rem; color: #c4b5fd; word-break: break-all; }

  /* Dashboard grid */
  .dash-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; }
  .dash-card { background: #0d0d14; border: 1px solid #1e1e2e; border-radius: 10px; padding: 1.2rem; }
  .dash-card .num { font-size: 1.8rem; font-weight: 700; color: #a78bfa; }
  .dash-card .lbl { font-size: .8rem; color: #6b7280; margin-top: .2rem; }

  /* URL hint */
  .url-hint { background: #0d0f0a; border: 1px solid #1a2e1a; border-radius: 8px; padding: .6rem 1rem; font-family: monospace; font-size: .82rem; color: #6b7280; margin-top: .5rem; }
  .url-hint span { color: #4ade80; }

  a.link { color: #a78bfa; text-decoration: none; }
  a.link:hover { text-decoration: underline; }
</style>
</head>
<body>

<nav class="navbar">
  <div class="logo">Ti3Lab <span>Academy</span></div>
  <?php if ($currentUser): ?>
  <div class="nav-links">
    <a href="?page=dashboard">Dashboard</a>
    <a href="?page=profile&id=<?= $currentUser['id'] ?>">My Profile</a>
    <a href="?page=logout" class="logout">Logout</a>
  </div>
  <?php endif; ?>
</nav>

<div class="container">

<?php if ($page === 'login'): ?>
<!-- ── LOGIN PAGE ── -->
<div style="max-width:420px;margin:4rem auto;">
  <div class="card">
    <h2>🔐 Student Login</h2>
    <?php if (isset($_SESSION['login_error'])): ?>
      <div class="alert alert-error"><?= $_SESSION['login_error']; unset($_SESSION['login_error']); ?></div>
    <?php endif; ?>
    <div class="alert alert-info" style="margin-bottom:1.2rem;">
      <strong>Your credentials:</strong><br>
      Email: <code>ahmed@ti3lab.com</code><br>
      Password: <code>ahmed123</code>
    </div>
    <form method="POST" action="?page=login">
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="you@ti3lab.com" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%">Login</button>
    </form>
  </div>
</div>

<?php elseif ($page === 'dashboard' && $currentUser): ?>
<!-- ── DASHBOARD ── -->
<div class="card" style="margin-bottom:1rem;">
  <h2>👋 Welcome back, <?= htmlspecialchars($currentUser['name']) ?></h2>
  <div class="dash-grid">
    <div class="dash-card"><div class="num">2</div><div class="lbl">Enrolled Courses</div></div>
    <div class="dash-card"><div class="num">1</div><div class="lbl">Completed</div></div>
  </div>
  <p style="color:#6b7280;font-size:.88rem;">Use the navigation above to view your profile and orders.</p>
</div>

<div class="card">
  <h2>📦 My Recent Orders</h2>
  <table>
    <tr><th>#</th><th>Item</th><th>Price</th><th>Status</th><th>Action</th></tr>
    <?php foreach ($orders as $o): if ($o['user_id'] == $currentUser['id']): ?>
    <tr>
      <td><?= $o['id'] ?></td>
      <td><?= htmlspecialchars($o['item']) ?></td>
      <td><?= $o['price'] ?></td>
      <td><span class="badge badge-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
      <td><a href="?page=order&id=<?= $o['id'] ?>" class="btn btn-sm btn-outline">View</a></td>
    </tr>
    <?php endif; endforeach; ?>
  </table>
  <div class="url-hint" style="margin-top:1rem;">
    💡 Hint: Notice the URL → <span>?page=order&id=<?= array_values(array_filter($orders, fn($o) => $o['user_id'] == $currentUser['id']))[0]['id'] ?? 1 ?></span>
  </div>
</div>

<?php elseif ($page === 'profile'): ?>
<!-- ── PROFILE PAGE (VULNERABLE TO IDOR) ── -->
<?php
$viewId = intval($_GET['id'] ?? $currentUser['id']);
$profile = $users[$viewId] ?? null;
?>
<?php if (!$profile): ?>
  <div class="alert alert-error">User not found.</div>
<?php else: ?>
<div class="card">
  <h2>👤 User Profile</h2>
  <div class="profile-header">
    <div class="avatar"><?= strtoupper($profile['name'][0]) ?></div>
    <div class="profile-info">
      <h3><?= htmlspecialchars($profile['name']) ?></h3>
      <span class="role-badge role-<?= $profile['role'] ?>"><?= strtoupper($profile['role']) ?></span>
    </div>
  </div>
  <table>
    <tr><th>Field</th><th>Value</th></tr>
    <tr><td>User ID</td><td><?= $profile['id'] ?></td></tr>
    <tr><td>Full Name</td><td><?= htmlspecialchars($profile['name']) ?></td></tr>
    <tr><td>Email</td><td><?= htmlspecialchars($profile['email']) ?></td></tr>
    <tr><td>Role</td><td><?= htmlspecialchars($profile['role']) ?></td></tr>
    <?php if (isset($profile['flag'])): ?>
    <tr>
      <td>🏆 Flag</td>
      <td>
        <div class="flag-box">
          <div class="flag-label">🎉 You found it!</div>
          <code><?= htmlspecialchars($profile['flag']) ?></code>
        </div>
      </td>
    </tr>
    <?php endif; ?>
  </table>

  <?php if ($viewId !== ($currentUser['id'] ?? 0)): ?>
    <div class="alert alert-info" style="margin-top:1rem;">
      ⚠️ You are viewing another user's profile. (User ID: <?= $viewId ?>)
    </div>
  <?php endif; ?>

  <div class="url-hint" style="margin-top:1rem;">
    Current URL → <span>?page=profile&id=<?= $viewId ?></span>
  </div>
</div>
<?php endif; ?>

<?php elseif ($page === 'order'): ?>
<!-- ── ORDER PAGE (ALSO VULNERABLE) ── -->
<?php $orderId = intval($_GET['id'] ?? 0); $order = $orders[$orderId] ?? null; ?>
<?php if (!$order): ?>
  <div class="alert alert-error">Order not found.</div>
<?php else: ?>
<div class="card">
  <h2>📄 Order Details</h2>
  <table>
    <tr><th>Field</th><th>Value</th></tr>
    <tr><td>Order ID</td><td>#<?= $order['id'] ?></td></tr>
    <tr><td>Item</td><td><?= htmlspecialchars($order['item']) ?></td></tr>
    <tr><td>Price</td><td><?= $order['price'] ?></td></tr>
    <tr><td>Status</td><td><span class="badge badge-<?= $order['status'] ?>"><?= $order['status'] ?></span></td></tr>
    <tr><td>User ID</td><td><?= $order['user_id'] ?></td></tr>
  </table>
  <?php if ($order['user_id'] != $currentUser['id']): ?>
    <div class="alert alert-error" style="margin-top:1rem;">
      ⚠️ This order belongs to User #<?= $order['user_id'] ?> — not you!
    </div>
  <?php endif; ?>
  <div class="url-hint" style="margin-top:1rem;">
    Current URL → <span>?page=order&id=<?= $orderId ?></span>
  </div>
</div>
<?php endif; ?>

<?php endif; ?>

</div><!-- /container -->
</body>
</html>

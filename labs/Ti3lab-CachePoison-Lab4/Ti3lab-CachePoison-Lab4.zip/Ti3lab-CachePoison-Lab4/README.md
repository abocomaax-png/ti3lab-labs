# Ti3lab - Cache Poisoning Lab 4
## Cache Deception: Sensitive Account Data Leak

**Difficulty:** Medium
**Category:** Web Cache Deception

---

## What is Cache Deception?

Cache Poisoning and Cache Deception are related but different:

- **Cache Poisoning**: the attacker tricks the cache into storing a *malicious* response that is then served to *other victims*.
- **Cache Deception**: the attacker tricks the cache into storing a *sensitive* response (belonging to a victim) and then *retrieves it themselves*.

A common cause of Cache Deception is **extension-based caching**: a caching proxy decides whether to cache a response based on the file extension at the end of the URL path (`.js`, `.css`, `.png`, etc.), regardless of:

- The actual `Content-Type` returned by the backend
- Whether the underlying endpoint is normally authenticated / non-cacheable

If a backend framework **ignores or strips** a trailing extension when routing a request, an authenticated endpoint can become reachable through a path that *looks* like a static asset — and the proxy will cache it.

### Attack Flow

```
Victim (logged in)                 Proxy (Cache)              Backend
   |                                    |                         |
   |-- GET /api/account/summary.js      |                         |
   |   Cookie: session=<victim>         |                         |
   |                                     |-- GET /api/account/summary.js -->|
   |                                     |   Cookie: session=<victim>
   |                                     |                         |
   |                                     |<-- account data ---------|
   |                                     |    (cached: matches *.js)
   |<-- account data ---------------------|                         |
   |                                     |                         |

Attacker (no session)                |                         |
   |-- GET /api/account/summary.js      |                         |
   |   (no cookie)                      |                         |
   |                                     |                         |
   |<-- VICTIM'S account data -----------|                         |
   |    (HIT from cache, no auth needed) |                         |
```

### Key Concepts

- **Extension-based caching**: proxies often cache `*.js`, `*.css`, `*.png` etc. by path pattern alone
- **Routing extension stripping**: some backends normalize `/resource.ext` to `/resource` when matching routes
- **X-Cache-Status: HIT**: confirms a response was served from cache, not generated fresh
- **Impact**: sensitive, per-user data becomes publicly accessible to anyone who requests the same cached path

---

## Lab Scenario

You are testing **SecureBank**, an online banking portal.

After logging in, you can view your account summary at `/api/account/summary`, which returns your balance, account number, and IBAN. This endpoint requires a valid session and is not cached.

Your task: find a way to make this sensitive endpoint get cached by the proxy, then retrieve the cached response **without being authenticated**.

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8081

Demo credentials: `karim` / `summer2024`

---

## Hints

<details>
<summary>Hint 1</summary>
Log in and inspect the request that loads your account summary. What happens if you request the exact same endpoint but append a static-asset extension like <code>.js</code> to the path, while still logged in?
</details>

<details>
<summary>Hint 2</summary>
Check the response headers for a cache status indicator. Does appending <code>.js</code> change whether the response gets cached, even though the content is still JSON account data?
</details>

<details>
<summary>Hint 3</summary>
Once a response to <code>/api/account/summary.js</code> has been cached while authenticated, try requesting the exact same path again — but this time without your session cookie (e.g. in a private/incognito window, or by removing the Cookie header in Burp Repeater).
</details>

<details>
<summary>Hint 4</summary>
A successful cache hit on the unauthenticated request should return the same account data as before. Look closely at the JSON — is there anything extra in the response this time?
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

from flask import Flask, request, jsonify, make_response

app = Flask(__name__)

VALID_SESSION = "sb_9f1a3c7e2b8d4f06a1e9c5d2b7a8f314"

ACCOUNT = {
    "account_holder": "Karim El-Sayed",
    "account_number": "EG12 SECB 0042 0098 7765 1100",
    "iban": "EG12SECB0042009877651100",
    "balance": 184250.37,
    "currency": "EGP",
    "account_type": "Premium Checking"
}

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    if data.get("username") == "karim" and data.get("password") == "summer2024":
        resp = make_response(jsonify({"status": "ok", "message": "Logged in successfully."}))
        resp.set_cookie("session", VALID_SESSION, httponly=True, path="/")
        return resp
    return jsonify({"status": "error", "message": "Invalid credentials."}), 401


@app.route("/api/account/summary")
@app.route("/api/account/summary.<ext>")
def account_summary(ext=None):
    session = request.cookies.get("session")

    if session != VALID_SESSION:
        return jsonify({"status": "error", "message": "Unauthorized. Please log in."}), 401

    response = dict(ACCOUNT)

    # The flag is embedded in the account data whenever this endpoint is
    # reached through a static-asset-style path (e.g. summary.js / summary.css).
    # On its own this requires a valid session and is not a vulnerability.
    # The vulnerability is that the proxy caches *.js / *.css responses by
    # path alone -- so once an authenticated request to summary.js is cached,
    # the SAME response (flag included) is served to subsequent requests for
    # that path even without a valid session.
    if ext is not None:
        response["flag"] = "Ti3lab{c4ch3_d3c3pt10n_4cc0unt_l34k}"

    return jsonify(response)


@app.route("/api/profile")
def profile():
    session = request.cookies.get("session")
    if session != VALID_SESSION:
        return jsonify({"status": "error", "message": "Unauthorized. Please log in."}), 401
    return jsonify({
        "name": "Karim El-Sayed",
        "email": "karim.elsayed@securebank.com",
        "member_since": "2019"
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

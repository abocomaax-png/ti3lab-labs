from flask import Flask, request, jsonify

app = Flask(__name__)

DEFAULT_CDN = "cdn.datapulse.io"

STATS = {
    "total_users": 48213,
    "revenue": 128450.75,
    "active_sessions": 1042,
    "conversion_rate": 3.8,
    "bounce_rate": 24.6
}

USER = {
    "name": "Demo User",
    "plan": "Pro",
    "email": "demo@datapulse.io",
    "avatar_initial": "D"
}

def get_cdn_host():
    # Vulnerable: the CDN host used to build the widgets script URL is taken
    # directly from a request header, but this header is NOT part of the
    # cache key used by the reverse proxy.
    return request.headers.get("X-CDN-Host", DEFAULT_CDN)

@app.route("/api/dashboard-config")
def dashboard_config():
    cdn_host = get_cdn_host()
    return jsonify({
        "app": "DataPulse",
        "version": "2.4.1",
        "theme": "dark",
        "cdn_host": cdn_host,
        "widgets_script": f"//{cdn_host}/widgets/loader.js",
        "analytics_script": f"//{cdn_host}/widgets/analytics.js",
        "flag": "Ti3lab{unk3y3d_cdn_h0st_xss_p01s0n}" if cdn_host != DEFAULT_CDN else None
    })

@app.route("/api/stats")
def stats():
    return jsonify(STATS)

@app.route("/api/user")
def user():
    return jsonify(USER)

@app.route("/api/notifications")
def notifications():
    return jsonify({
        "unread": 3,
        "items": [
            {"id": 1, "text": "Weekly report is ready", "type": "info"},
            {"id": 2, "text": "New team member joined", "type": "success"},
            {"id": 3, "text": "Storage usage at 82%", "type": "warning"}
        ]
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# Ti3lab - Cache Poisoning Lab 3
## Cache Poisoning to XSS via JS Resource (Unkeyed CDN Host Header)

**Difficulty:** Medium
**Category:** Web Cache Poisoning

---

## What is an Unkeyed Header?

A cache key is what the proxy uses to decide whether a stored response can be served to a new request.
Typically the cache key is built from the URI and query string only.

If the backend uses a request **Header** to change its response, but the cache does not include that header in the cache key, it becomes an **unkeyed input**.

This means:
- Two requests to the same URI with different header values share the same cached response
- An attacker can send a request with a crafted header, get a manipulated response cached, and every subsequent visitor receives that manipulated response

### Attack Flow

```
Attacker                        Proxy (Cache)              Backend
   |                                 |                         |
   |-- GET /api/dashboard-config     |                         |
   |   X-CDN-Host: attacker.com      |                         |
   |                                 |-- GET /api/dashboard-config ->|
   |                                 |   X-CDN-Host: attacker.com
   |                                 |                         |
   |                                 |<-- poisoned response ----|
   |                                 |    (cached under /api/dashboard-config)
   |<-- poisoned response -----------|                         |
   |                                 |                         |
Victim                               |                         |
   |-- GET /api/dashboard-config     |                         |
   |   (no X-CDN-Host header)        |                         |
   |                                 |                         |
   |<-- POISONED response -----------|                         |
   |    (HIT from cache)             |                         |
   |    widgets_script -> //attacker.com/widgets/loader.js     |
```

### Key Concepts

- **Cache key**: usually URI + query string only — custom headers are typically excluded
- **Unkeyed Header**: a header the backend uses but the cache ignores
- **X-Cache-Status: HIT**: confirms the response came from cache
- **Impact**: every user's browser is told to load a JavaScript bundle from a host the attacker controls, which leads to stored XSS for all visitors

---

## Lab Scenario

You are looking at **DataPulse**, a SaaS analytics dashboard.

The dashboard loads an interactive "widgets" bundle from a CDN. The CDN host used to build the script URL comes from a request header sent to the `/api/dashboard-config` endpoint.

However, the caching proxy builds its cache key from the URI only, not from this header. This means if you send a request with a custom CDN host, the backend returns a different `widgets_script` URL — and the proxy caches it for all future visitors.

Your goal is to identify the unkeyed header, control the CDN host returned in the config, and poison the cache so that the dashboard config served to everyone points to a host of your choosing.

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8092

---

## Hints

<details>
<summary>Hint 1</summary>
Browse the dashboard and look at the API calls being made in the Network tab.
Which endpoint decides where the "widgets" bundle is loaded from? Check its response headers — is there a cache status header?
</details>

<details>
<summary>Hint 2</summary>
The dashboard config response includes a `cdn_host` field and a `widgets_script` URL. What determines the value of `cdn_host`? Try sending the request with extra headers in Burp.
</details>

<details>
<summary>Hint 3</summary>
The cache key is the URI only. Custom headers are not part of the key.
If you send a poisoned request and it gets a MISS (stored), the next request without that header will get a HIT with your value.
</details>

<details>
<summary>Hint 4</summary>
What happens to the response when the CDN host is something other than the default `cdn.datapulse.io`? Look carefully at the JSON — does an extra field appear?
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

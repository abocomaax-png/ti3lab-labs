from flask import Flask, request, jsonify

app = Flask(__name__)

# Simulated search index
RESULTS = {
    "laptops": [
        {"title": "UltraBook Pro 14\"", "price": "$1,299", "category": "Laptops"},
        {"title": "AeroLite 13 Slim", "price": "$899", "category": "Laptops"},
        {"title": "GameForce X15", "price": "$1,799", "category": "Laptops"},
    ],
    "headphones": [
        {"title": "SoundWave ANC Pro", "price": "$199", "category": "Audio"},
        {"title": "ClearTone Lite", "price": "$59", "category": "Audio"},
    ],
    "monitors": [
        {"title": "VividView 27\" 4K", "price": "$429", "category": "Monitors"},
        {"title": "CurveMax 34\" Ultrawide", "price": "$649", "category": "Monitors"},
    ],
}

DEFAULT_RESULTS = [
    {"title": "No matching products found", "price": "-", "category": "-"}
]

ADMIN_SECRET_RESULTS = [
    {
        "title": "INTERNAL: Q3 Pricing Strategy Draft.pdf",
        "price": "CONFIDENTIAL",
        "category": "Internal Documents"
    },
    {
        "title": "INTERNAL: Staging API Credentials.txt",
        "price": "CONFIDENTIAL",
        "category": "Internal Documents"
    },
]


def parse_body_param(raw_body, param_name="q"):
    """
    Parse a x-www-form-urlencoded body, supporting BOTH '&' (standard) and
    ';' (legacy parameter separator, e.g. old Ruby/Sinatra/Rack behavior) as
    delimiters between key=value pairs. Returns the value for `param_name`
    if present, else None.

    This dual-delimiter support is the source of the parameter cloaking
    twist: a single body parameter using ';' can carry a second, hidden
    value for 'q' that a naive '&'-only parser (or the cache) would never
    see as a separate parameter.
    """
    if not raw_body:
        return None

    raw_body = raw_body.strip()

    # Normalize ';' separators to '&' so both styles are parsed uniformly
    normalized = raw_body.replace(";", "&")

    pairs = normalized.split("&")
    # Last occurrence wins (mirrors how many real backends overwrite
    # earlier values for the same key when parsing form bodies)
    value = None
    for pair in pairs:
        if "=" not in pair:
            continue
        key, _, val = pair.partition("=")
        if key.strip() == param_name:
            value = val.strip()

    return value


@app.route("/api/search")
def search():
    url_query = request.args.get("q", "")

    raw_body = request.get_data(as_text=True)
    body_query = parse_body_param(raw_body, "q")

    # Fat GET: if the body carries its own 'q' parameter, the backend uses
    # IT instead of the URL query string -- but the cache only ever sees
    # the URL query string when building its cache key.
    effective_query = body_query if body_query else url_query

    key = effective_query.strip().lower()

    if key == "admin-secret-query":
        results = ADMIN_SECRET_RESULTS
        flag = "Ti3lab{f4t_g3t_p4r4m_cl04k1ng_c4ch3}"
    else:
        results = RESULTS.get(key, DEFAULT_RESULTS)
        flag = None

    response = {
        "query": effective_query,
        "results": results,
        "count": len(results)
    }
    if flag:
        response["flag"] = flag

    return jsonify(response)


@app.route("/api/trending")
def trending():
    return jsonify({
        "trending": ["laptops", "headphones", "monitors", "smartwatches"]
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

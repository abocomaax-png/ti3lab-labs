# Ti3lab - Cache Poisoning Lab 5
## Fat GET + Parameter Cloaking

**Difficulty:** Medium-Hard
**Category:** Web Cache Poisoning

---

## What is a "Fat GET"?

HTTP `GET` requests are not supposed to carry a meaningful body, but nothing in the HTTP specification forbids it -- and many web servers will happily read one if present.

Some backends are written to prefer parameters from the **request body** over parameters from the **URL query string**, even on `GET` requests. If a caching proxy:

- Builds its cache key from the **URL query string only**, and
- **Ignores or doesn't inspect** the request body at all

...then an attacker can send a `GET` request where the URL query string looks harmless, but the body contains a different value that the backend actually uses to generate the response. The proxy caches the body-derived response under the harmless-looking URL key.

### What is Parameter Cloaking?

Some frameworks historically accepted `;` as an alternative separator between body/query parameters (instead of `&`). If a parser treats `;` and `&` differently -- or a downstream component only recognizes `&` -- an attacker can "hide" a second value for the same parameter name inside what looks like a single parameter, smuggling a value past components that only see the first occurrence (or vice versa).

### Attack Flow

```
Attacker                              Proxy (Cache)              Backend
   |                                       |                         |
   |-- GET /api/search?q=laptops           |                         |
   |   Content-Type: x-www-form-urlencoded |                         |
   |   Body: q=admin-secret-query          |                         |
   |                                       |-- forwards URI + body -->|
   |                                       |                         |
   |                                       |   backend reads 'q' from BODY
   |                                       |   -> returns results for
   |                                       |      "admin-secret-query"
   |                                       |                         |
   |                                       |<-- response (admin data) |
   |                                       |    cached under key:
   |                                       |    /api/search?q=laptops
   |<-- response (admin data) --------------|                         |
   |                                       |                         |

Victim                                    |                         |
   |-- GET /api/search?q=laptops           |                         |
   |   (normal request, no body)           |                         |
   |                                       |                         |
   |<-- POISONED response ------------------|                         |
   |    (HIT from cache)                    |                         |
   |    contains "admin-secret-query" data  |                         |
```

### Key Concepts

- **Cache key**: built from URI + query string only -- the body is invisible to the cache
- **Fat GET**: a `GET` request carrying a body that the backend actually reads
- **Parameter precedence**: many backends prioritize body parameters over query parameters for the same key
- **Parameter Cloaking**: using `;` as a separator to smuggle an extra parameter value past a parser that expects `&`
- **X-Cache-Status: HIT**: confirms the poisoned response is being served from cache to subsequent requests

---

## Lab Scenario

You are testing **NovaSearch**, a product search engine.

Searching is done via:

```
GET /api/search?q=<your query>
```

The response is cached by the proxy based on the URL query string. Your task is to find a way to make the cache store a response for `?q=laptops` that actually contains a different, sensitive result set -- one that should never be associated with that public search term.

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8083

---

## Hints

<details>
<summary>Hint 1</summary>
The search endpoint only accepts <code>GET</code> requests. What happens if you send a <code>GET</code> request to <code>/api/search?q=laptops</code> that also includes a request body with a different <code>q</code> parameter?
</details>

<details>
<summary>Hint 2</summary>
In Burp Repeater, add a <code>Content-Type: application/x-www-form-urlencoded</code> header and a body like <code>q=something-else</code> to a GET request. Compare the <code>query</code> field in the JSON response to the URL you requested.
</details>

<details>
<summary>Hint 3</summary>
Once you've confirmed the backend prefers the body's <code>q</code> over the URL's <code>q</code>, check the <code>X-Cache-Status</code> header. If the poisoned response is stored (MISS), try requesting <code>/api/search?q=laptops</code> again -- this time with no body at all.
</details>

<details>
<summary>Hint 4</summary>
What value, if used as the hidden <code>q</code> parameter in the body, returns a result set that looks like it shouldn't be publicly searchable? Look for anything that hints at "admin" or "internal" content.
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

# Ti3lab - Cache Poisoning Lab 6
## Cache Poisoning via URL Discrepancies

**Difficulty:** Hard
**Category:** Web Cache Poisoning

---

## What is a URL Discrepancy?

A caching proxy and the backend it sits in front of don't always agree on what a URL "means".

A reverse proxy like nginx will often **normalize** the request path internally -- decoding percent-encoded characters and collapsing `.` / `..` segments -- before deciding what to use as a **cache key**. However, the proxy may forward a **different, raw** representation of the URL to the backend (e.g. the original, un-normalized request line).

If the backend then performs its **own** path resolution on that raw value -- independently, and with different rules than the proxy -- the path the cache thinks it stored a response *for* can diverge from the path the backend actually *generated a response for*.

### Attack Flow

```
Attacker                              Proxy (Cache)              Backend
   |                                       |                         |
   |-- GET /api/posts/%2e%2e/admin/config  |                         |
   |                                       |                         |
   |   Proxy normalizes for cache key:     |                         |
   |     $uri = /api/admin/config          |                         |
   |                                       |                         |
   |   Proxy forwards RAW request to       |                         |
   |   backend:                            |                         |
   |     /api/posts/%2e%2e/admin/config -->|                         |
   |                                       |                         |
   |                                       |   Backend decodes %2e%2e
   |                                       |   and resolves the path
   |                                       |   itself -> /api/admin/config
   |                                       |                         |
   |                                       |<-- admin config response |
   |                                       |    cached under key:
   |                                       |    /api/admin/config
   |<-- admin config response --------------|                         |

Anyone (no special request needed)        |                         |
   |-- GET /api/admin/config                |                         |
   |   (normally returns 403 Forbidden)     |                         |
   |                                       |                         |
   |<-- LEAKED admin config -----------------|                         |
   |    (HIT from cache, backend never      |                         |
   |     re-checks access control)          |                         |
```

### Key Concepts

- **Cache key derivation**: proxies often normalize the URL (decode `%2e%2e`, collapse `..`) before computing the cache key
- **Raw forwarding**: the backend may receive the original, un-normalized URL and resolve it independently
- **Divergence**: a single attacker request can be *cached under one path* while *responding with the content of a completely different path*
- **Impact**: a normally access-controlled endpoint (`/api/admin/config`, returns `403` directly) becomes publicly readable from the cache once poisoned under its own path

---

## Lab Scenario

You are testing **DevPortal**, a developer documentation and blog platform.

Blog posts are served from `/api/posts/<slug>`, e.g. `/api/posts/latest`. There is also an internal configuration endpoint, `/api/admin/config`, which correctly returns `403 Forbidden` when accessed directly.

Your task: find a request that causes the caching proxy to compute a cache key that does **not** match the path the backend actually responds for -- and use this to make the cache store and serve the contents of `/api/admin/config` to unauthenticated requests.

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8084

---

## Hints

<details>
<summary>Hint 1</summary>
The blog posts endpoint is <code>/api/posts/&lt;slug&gt;</code>. What happens if <code>&lt;slug&gt;</code> contains an encoded path traversal sequence, like <code>%2e%2e</code>, followed by a different path?
</details>

<details>
<summary>Hint 2</summary>
Try requesting <code>/api/posts/%2e%2e/admin/config</code> directly. Compare the JSON body you get back to what <code>/api/admin/config</code> normally returns (<code>403 Forbidden</code>). What does this tell you about how the backend resolves the path, versus how the cache might see it?
</details>

<details>
<summary>Hint 3</summary>
Check the <code>X-Cache-Status</code> header on the traversal request. If the response was stored (<code>MISS</code>), think about what URL the <strong>proxy</strong> normalized this request to for caching purposes -- it's unlikely to be the same as <code>/api/posts/%2e%2e/admin/config</code>.
</details>

<details>
<summary>Hint 4</summary>
If the proxy normalizes <code>/api/posts/%2e%2e/admin/config</code> down to <code>/api/admin/config</code> for its cache key, what happens if you request <code>/api/admin/config</code> directly afterwards? Check the <code>X-Cache-Status</code> header on that follow-up request.
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

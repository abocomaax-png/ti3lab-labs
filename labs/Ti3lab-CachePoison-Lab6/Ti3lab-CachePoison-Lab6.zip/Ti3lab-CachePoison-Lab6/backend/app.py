from flask import Flask, jsonify
import posixpath

app = Flask(__name__)

POSTS = {
    "latest": {
        "title": "Introducing API v3: Faster, Safer, Simpler",
        "author": "DevPortal Team",
        "date": "2026-06-10",
        "body": "We're excited to announce the general availability of API v3. "
                "This release focuses on performance improvements, a redesigned "
                "authentication flow, and expanded rate limits for Pro accounts."
    },
    "changelog": {
        "title": "June 2026 Changelog",
        "author": "DevPortal Team",
        "date": "2026-06-01",
        "body": "Bug fixes, dependency upgrades, and minor UI polish across the docs site."
    },
    "migration-guide": {
        "title": "Migrating from API v2 to v3",
        "author": "DevPortal Team",
        "date": "2026-05-20",
        "body": "Step-by-step guide for updating your integration to use API v3 endpoints "
                "and the new authentication scheme."
    }
}

DEFAULT_POST = {
    "title": "Post not found",
    "author": "-",
    "date": "-",
    "body": "The requested post does not exist."
}

ADMIN_CONFIG = {
    "service": "DevPortal Admin Panel",
    "environment": "production",
    "database_url": "postgres://admin:r00tP@ssw0rd@db.internal:5432/devportal",
    "api_signing_key": "sk_live_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
    "smtp_credentials": "noreply@devportal.io:SuperSecretSmtp!2026",
    "flag": "Ti3lab{url_d1screp4ncy_4dm1n_c0nf1g_l34k}"
}


@app.route("/api/admin/config")
def admin_config_direct():
    # Direct, unauthenticated access to this endpoint is correctly blocked.
    return jsonify({"status": "error", "message": "Forbidden"}), 403


@app.route("/api/posts/<path:subpath>")
def posts(subpath):
    # This backend resolves the requested path itself, independently of how
    # the front-end caching proxy normalized the URL. A path containing
    # encoded traversal sequences (e.g. %2e%2e) is decoded by the framework
    # before reaching this handler, and is then resolved against /api/posts/
    # using standard path normalization -- which can walk the request
    # outside of /api/posts/ entirely.
    resolved = posixpath.normpath("/api/posts/" + subpath)

    if resolved == "/api/admin/config":
        return jsonify(ADMIN_CONFIG)

    if resolved.startswith("/api/posts/"):
        slug = resolved.rsplit("/", 1)[-1]
        return jsonify(POSTS.get(slug, DEFAULT_POST))

    return jsonify({"status": "error", "message": "Not found"}), 404


@app.route("/api/posts")
def posts_index():
    return jsonify({"posts": list(POSTS.keys())})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

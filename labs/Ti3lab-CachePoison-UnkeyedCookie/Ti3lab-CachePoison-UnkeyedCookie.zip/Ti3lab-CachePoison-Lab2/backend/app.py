from flask import Flask, request, jsonify

app = Flask(__name__)

PRODUCTS = {
    "1": {"id": "1", "name": "Mechanical Keyboard TKL", "category": "Peripherals", "price": 129.99, "stock": 14},
    "2": {"id": "2", "name": "27\" IPS Monitor 144Hz", "category": "Displays", "price": 349.99, "stock": 7},
    "3": {"id": "3", "name": "USB-C Docking Station", "category": "Accessories", "price": 89.99, "stock": 23},
    "4": {"id": "4", "name": "Wireless Ergonomic Mouse", "category": "Peripherals", "price": 69.99, "stock": 31},
    "5": {"id": "5", "name": "NVMe SSD 1TB", "category": "Storage", "price": 94.99, "stock": 18},
}

CURRENCY_RATES = {
    "USD": 1.0,
    "EUR": 0.92,
    "GBP": 0.79,
    "JPY": 149.50,
}

CURRENCY_SYMBOLS = {
    "USD": "$",
    "EUR": "€",
    "GBP": "£",
    "JPY": "¥",
}

def get_currency():
    # Vulnerable: reads currency from cookie, unkeyed in cache
    return request.cookies.get("currency", "USD").upper()

def format_price(price, currency):
    rate = CURRENCY_RATES.get(currency, 1.0)
    symbol = CURRENCY_SYMBOLS.get(currency, "$")
    converted = round(price * rate, 2)
    if currency == "JPY":
        return f"{symbol}{int(converted)}"
    return f"{symbol}{converted:.2f}"

@app.route("/api/products")
def list_products():
    currency = get_currency()
    products = []
    for p in PRODUCTS.values():
        products.append({
            **p,
            "display_price": format_price(p["price"], currency),
            "currency": currency
        })
    return jsonify({
        "products": products,
        "currency": currency,
        "total": len(products)
    })

@app.route("/api/products/<product_id>")
def get_product(product_id):
    product = PRODUCTS.get(product_id)
    if not product:
        return jsonify({"error": "Product not found"}), 404
    currency = get_currency()
    return jsonify({
        **product,
        "display_price": format_price(product["price"], currency),
        "currency": currency
    })

@app.route("/api/store-info")
def store_info():
    currency = get_currency()
    return jsonify({
        "store": "NexCart",
        "tagline": "Premium Tech. Honest Prices.",
        "currency": currency,
        "currency_symbol": CURRENCY_SYMBOLS.get(currency, "$"),
        "shipping": format_price(9.99, currency),
        "free_shipping_threshold": format_price(75.0, currency),
        "announcement": f"Free shipping on orders over {format_price(75.0, currency)}",
        "flag": "Ti3lab{unkeyed_c00k13_c4ch3_p01s0n}" if currency not in ["USD", "EUR", "GBP", "JPY"] else None
    })

@app.route("/api/cart/summary")
def cart_summary():
    currency = get_currency()
    return jsonify({
        "items": 0,
        "subtotal": format_price(0, currency),
        "currency": currency
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

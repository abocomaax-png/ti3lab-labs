# Ti3lab - Cache Poisoning Lab 2
## Unkeyed Cookie Reflection

**Difficulty:** Easy-Medium
**Category:** Web Cache Poisoning

---

## What is an Unkeyed Input?

A cache key is what the proxy uses to decide whether a stored response can be served to a new request.
Typically the cache key is built from the URI and query string only.

If the backend uses a **Cookie**, **Header**, or **Parameter** to change its response, but the cache does not include that value in the cache key, it becomes an **unkeyed input**.

This means:
- Two requests to the same URI with different cookie values share the same cached response
- An attacker can send a request with a crafted cookie, get a manipulated response cached, and every subsequent visitor receives that manipulated response

### Attack Flow

```
Attacker                        Proxy (Cache)              Backend
   |                                 |                         |
   |-- GET /api/store-info           |                         |
   |   Cookie: currency=POISON       |                         |
   |                                 |-- GET /api/store-info ->|
   |                                 |   Cookie: currency=POISON
   |                                 |                         |
   |                                 |<-- poisoned response ----|
   |                                 |    (cached under /api/store-info)
   |<-- poisoned response -----------|                         |
   |                                 |                         |
Victim                               |                         |
   |-- GET /api/store-info           |                         |
   |   Cookie: currency=USD          |                         |
   |                                 |                         |
   |<-- POISONED response -----------|                         |
   |    (HIT from cache)             |                         |
```

### Key Concepts

- **Cache key**: usually URI + query string only — cookies are typically excluded
- **Unkeyed Cookie**: a cookie the backend uses but the cache ignores
- **X-Cache-Status: HIT**: confirms the response came from cache
- **Impact**: every user gets the attacker's manipulated response

---

## Lab Scenario

You are looking at **NexCart**, an e-commerce store that sells tech hardware.

The store supports multiple currencies. The selected currency is stored in a cookie and sent with every API request. The backend uses this cookie to format prices in the response.

However, the caching proxy builds its cache key from the URI only, not from the cookie. This means if you send a request with an unusual cookie value, the backend returns a different response — and the proxy caches it for all future visitors.

Your goal is to identify the unkeyed cookie, craft a value that triggers unexpected backend behavior, and poison the cache.

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8091

---

## Hints

<details>
<summary>Hint 1</summary>
Browse the site and look at the API calls being made in the Network tab.
Which endpoint is responsible for the store announcement and currency display?
Check its response headers — is there a cache status header?
</details>

<details>
<summary>Hint 2</summary>
The site uses a cookie to set the currency. Try modifying it in Burp.
Send a request to the store-info endpoint with a cookie like: currency=XYZ
Does the response change?
</details>

<details>
<summary>Hint 3</summary>
The cache key is the URI only. The cookie is not part of the key.
If you send a poisoned request and it gets a MISS (stored), the next request without that cookie will get a HIT with your value.
</details>

<details>
<summary>Hint 4</summary>
What happens when the currency cookie is set to a value that is not a real currency?
Look carefully at the response — does something unexpected appear?
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

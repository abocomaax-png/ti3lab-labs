from flask import Flask, request, jsonify, make_response
import jwt
import time
import requests as req

app = Flask(__name__)

SECRET_KEY = "ti3lab-super-secret-2024"
INTERNAL_SERVICE = "http://internal:6000"

def get_token_from_request():
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:]
    return None

def decode_token(token):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except Exception:
        return None

@app.route("/")
def index():
    return jsonify({
        "lab": "Ti3lab - Lab 3: Combined Auth Bypass",
        "endpoints": ["/login", "/dashboard", "/internal-fetch", "/admin-only"]
    })

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username", "")
    password = data.get("password", "")

    users = {
        "guest": "guest123",
        "user": "user456"
    }

    if username in users and users[username] == password:
        payload = {
            "sub": username,
            "role": "user",
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
        return jsonify({"token": token})

    return jsonify({"error": "Invalid credentials"}), 401

@app.route("/dashboard")
def dashboard():
    token = get_token_from_request()
    if not token:
        return jsonify({"error": "No token provided"}), 401

    payload = decode_token(token)
    if not payload:
        return jsonify({"error": "Invalid token"}), 401

    # Vulnerable: trusts X-Forwarded-Role header if proxy supposedly stripped it
    forwarded_role = request.headers.get("X-Forwarded-Role", None)
    role = forwarded_role if forwarded_role else payload.get("role", "user")

    return jsonify({
        "username": payload["sub"],
        "role": role,
        "message": f"Dashboard for {role} role",
        "tip": "Some endpoints require admin role"
    })

@app.route("/admin-only")
def admin_only():
    token = get_token_from_request()
    if not token:
        return jsonify({"error": "No token provided"}), 401

    payload = decode_token(token)
    if not payload:
        return jsonify({"error": "Invalid token"}), 401

    forwarded_role = request.headers.get("X-Forwarded-Role", None)
    role = forwarded_role if forwarded_role else payload.get("role", "user")

    if role != "admin":
        return jsonify({"error": "Admin access required", "your_role": role}), 403

    return jsonify({
        "status": "access_granted",
        "flag": "Ti3lab{h0p_4uth_byp4ss_c0mbin3d_4tt4ck}",
        "admin_data": "Ti3lab internal config: db_pass=s3cr3t, api_key=Ti3lab-API-2024"
    })

@app.route("/internal-fetch")
def internal_fetch():
    token = get_token_from_request()
    if not token:
        return jsonify({"error": "No token"}), 401

    payload = decode_token(token)
    if not payload:
        return jsonify({"error": "Invalid token"}), 401

    path = request.args.get("path", "/status")
    # Vulnerable: allows fetching from internal service
    try:
        resp = req.get(f"{INTERNAL_SERVICE}{path}", timeout=3)
        return jsonify({"data": resp.json()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

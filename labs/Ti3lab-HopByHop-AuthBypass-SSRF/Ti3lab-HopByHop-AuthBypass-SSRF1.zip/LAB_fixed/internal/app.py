from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/status")
def status():
    return jsonify({"status": "internal service running", "note": "This service is not exposed externally"})

@app.route("/secrets")
def secrets():
    return jsonify({
        "internal_flag": "Ti3lab{ss3rf_int3rn4l_s3rv1c3_r34ch3d}",
        "db_credentials": {
            "host": "db.ti3lab.internal",
            "user": "admin",
            "pass": "Ti3lab-DB-Secret"
        }
    })

@app.route("/admin-token")
def admin_token():
    return jsonify({
        "note": "This endpoint reveals the admin signing approach",
        "hint": "The JWT secret is used across all tokens"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=6000)

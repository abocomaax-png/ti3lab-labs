# Ti3lab - Lab 3: Combined Auth Bypass

**Difficulty:** Hard  
**Category:** Hop-by-Hop / JWT / SSRF / Privilege Escalation

---

## Setup

```bash
docker compose up --build
```

Lab runs on: http://localhost:8083

---

## Architecture

```
[You] --> [Nginx :80] --> [Backend :5000] --> [Internal :6000]
                                    ^
                            (only reachable from backend)
```

The internal service is on an isolated Docker network.  
It is not exposed to the outside world at all.

---

## Objective

This lab has two flags. Find both.

**Flag 1:** Access `/admin-only` without being an admin user  
**Flag 2:** Reach the internal service and extract its secrets

---

## Credentials

```
username: guest  password: guest123
username: user   password: user456
```

---

## Endpoints

| Endpoint         | Description                          |
|------------------|--------------------------------------|
| /login           | POST - returns JWT token             |
| /dashboard       | GET - shows your current role        |
| /admin-only      | GET - requires admin role            |
| /internal-fetch  | GET - fetches from internal service  |

---

## Background

This lab combines three techniques:

1. Hop-by-hop header injection to influence role resolution  
2. JWT authentication that relies on a header the proxy should sanitize  
3. SSRF via a server-side fetch endpoint that reaches an isolated internal service

The proxy is supposed to be the trust boundary. The backend trusts certain headers  
that are meant to be set only by the proxy. But the proxy forwards them from the client.

---

## Hints

<details>
<summary>Hint 1 - Flag 1</summary>
Login as any valid user and get a JWT token.
Hit /dashboard and observe the response. What header affects the role field?
</details>

<details>
<summary>Hint 2 - Flag 1</summary>
The backend trusts X-Forwarded-Role to override the role in the JWT.
The proxy forwards this header from the client without validation.
What happens if you send X-Forwarded-Role: admin with your request?
</details>

<details>
<summary>Hint 3 - Flag 2</summary>
The /internal-fetch endpoint accepts a path parameter.
It fetches from an internal service not accessible from outside.
Try: /internal-fetch?path=/status first to understand what it connects to.
</details>

<details>
<summary>Hint 4 - Flag 2</summary>
Once you know the internal service exists, enumerate its paths.
What sensitive endpoints might exist on an internal service?
Try /secrets.
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```

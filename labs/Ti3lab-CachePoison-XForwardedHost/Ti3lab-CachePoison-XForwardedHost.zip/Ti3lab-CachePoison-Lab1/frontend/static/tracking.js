// Veridia Finance - Analytics
(function() {
  var _vf = { version: "1.0.2", loaded: true };
  window._vf = _vf;
})();

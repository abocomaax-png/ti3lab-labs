from flask import Flask, request, jsonify

app = Flask(__name__)

ARTICLES = {
    "1": {
        "id": "1",
        "title": "Global Markets Rally as Inflation Data Eases",
        "author": "Sarah Mitchell",
        "category": "Markets",
        "content": "Financial markets surged on Wednesday following the release of lower-than-expected inflation figures, with major indices posting their strongest gains in months.",
        "published": "2024-06-10"
    },
    "2": {
        "id": "2",
        "title": "Central Bank Holds Interest Rates Steady",
        "author": "James Whitfield",
        "category": "Policy",
        "content": "The central bank announced today it would maintain current interest rate levels, citing ongoing uncertainty in the global economic outlook.",
        "published": "2024-06-09"
    },
    "3": {
        "id": "3",
        "title": "Tech Sector Leads Weekly Gains Amid AI Optimism",
        "author": "Diana Park",
        "category": "Technology",
        "content": "Technology stocks outperformed broader markets this week, driven by renewed investor enthusiasm around artificial intelligence infrastructure spending.",
        "published": "2024-06-08"
    }
}

def get_forwarded_host():
    # Accept both X-Forwarded-Host and X-Forward-Host
    return (
        request.headers.get("X-Forwarded-Host") or
        request.headers.get("X-Forward-Host")
    )

@app.route("/api/articles")
def list_articles():
    return jsonify({"articles": list(ARTICLES.values())})

@app.route("/api/articles/<article_id>")
def get_article(article_id):
    article = ARTICLES.get(article_id)
    if not article:
        return jsonify({"error": "Article not found"}), 404
    return jsonify(article)

@app.route("/api/home")
def home():
    forwarded_host = get_forwarded_host()
    host = forwarded_host if forwarded_host else request.headers.get("Host", "localhost")

    response = {
        "site": "Veridia Finance",
        "tagline": "Markets, Analysis & Insight",
        "canonical_url": f"https://{host}/",
        "assets": {
            "stylesheet": f"https://{host}/static/main.css",
            "logo": f"https://{host}/static/logo.png",
            "tracking": f"https://{host}/static/tracking.js"
        },
        "featured": list(ARTICLES.values())[:2],
        "flag": "Ti3lab{xfh_c4ch3_p01s0n_gl0b4l}" if forwarded_host else None
    }

    return jsonify(response)

@app.route("/api/search")
def search():
    q = request.args.get("q", "")
    forwarded_host = get_forwarded_host()
    host = forwarded_host if forwarded_host else request.headers.get("Host", "localhost")
    results = [a for a in ARTICLES.values() if q.lower() in a["title"].lower()]
    return jsonify({
        "query": q,
        "results": results,
        "share_url": f"https://{host}/search?q={q}"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# Ti3lab - Cache Poisoning Lab 1
## X-Forwarded-Host Global Cache Poisoning

**Difficulty:** Easy  
**Category:** Web Cache Poisoning

---

## What is Web Cache Poisoning?

Web cache poisoning is an attack where the attacker manipulates a caching proxy into storing a malicious response and serving it to other users.

Caching proxies store responses based on a **cache key**, which is usually built from the request URI and sometimes specific headers. The problem arises when the backend uses headers that are **not part of the cache key** to build its response. These are called **unkeyed inputs**.

If an attacker sends a request with a malicious unkeyed header, the backend returns a poisoned response. The cache stores it under the normal key. Every subsequent user who requests the same URI receives the poisoned response without ever sending the malicious header themselves.

### How the Attack Works

```
Attacker                     Proxy (Cache)               Backend
   |                              |                          |
   |-- GET /page                  |                          |
   |   X-Forwarded-Host: evil.com |                          |
   |                              |-- GET /page ------------>|
   |                              |   X-Forwarded-Host: evil.com
   |                              |                          |
   |                              |<-- response with evil.com in body
   |                              |    (cached under key: /page)
   |<-- poisoned response --------|                          |
   |                              |                          |
Victim                            |                          |
   |-- GET /page                  |                          |
   |   (no special headers)       |                          |
   |                              |                          |
   |<-- poisoned response --------|                          |
   |    (served from cache)       |                          |
```

### Key Concepts

- **Cache key**: what the proxy uses to decide if a stored response can be reused
- **Unkeyed input**: a request header or parameter the backend uses but the cache ignores
- **X-Cache header**: tells you if a response came from cache (HIT) or origin (MISS)
- **Cache-Control header**: controls how long a response stays cached

---

## Lab Scenario

You are looking at **Veridia Finance**, a financial news portal running behind a caching proxy.

The site loads its homepage content dynamically from an internal API. That API uses a request header to construct asset URLs in its JSON response. The caching proxy stores this API response but does not include that header in its cache key.

Your goal is to identify the unkeyed input, craft a poisoned request, and confirm the cache serves your manipulated response to subsequent visitors.

---

## Setup

```bash
docker compose up --build
```

Site runs on: http://localhost:8090

---

## Hints

<details>
<summary>Hint 1</summary>
Browse the site and intercept the traffic. The homepage makes API calls to load its content.
Look at the response headers — is there one that tells you whether the response came from cache or origin?
</details>

<details>
<summary>Hint 2</summary>
Find the API endpoint that returns asset URLs in its response.
Try adding X-Forwarded-Host to that request with a value you control.
Does it appear in the response?
</details>

<details>
<summary>Hint 3</summary>
The cache key does not include X-Forwarded-Host.
Send the poisoned request, then immediately request the same endpoint without the header.
What do you get back?
</details>

<details>
<summary>Hint 4</summary>
Once you confirm the cache is storing your poisoned response, think about the impact.
The page loads a script using the URL from the API response.
What happens when that URL points to a host you control?
</details>

---

## Reset

```bash
docker compose down -v && docker compose up --build
```
